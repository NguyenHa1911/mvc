const mix = require("laravel-mix");

require("laravel-mix-nunjucks");
const assetsPath = "resources/";
const assetsPublicPath = "public/assets/";
mix
  .sass(`${assetsPath}scss/app.scss`, `${assetsPublicPath}/css`)
  .sass(`${assetsPath}scss/bootstrap.scss`, `${assetsPublicPath}css`)
  .sass(`${assetsPath}scss/pages/auth.scss`, `${assetsPublicPath}css/pages`)
  .sass(`${assetsPath}scss/pages/error.scss`, `${assetsPublicPath}css/pages`)
  .sass(`${assetsPath}scss/pages/email.scss`, `${assetsPublicPath}css/pages`)
  .sass(`${assetsPath}scss/pages/chat.scss`, `${assetsPublicPath}css/pages`)
  .sass(`${assetsPath}scss/widgets/chat.scss`, `${assetsPublicPath}css/widgets`)
  .sass(`${assetsPath}scss/widgets/todo.scss`, `${assetsPublicPath}css/widgets`)
  .js(`${assetsPath}js/mazer.js`, `${assetsPublicPath}js`)
  .minify(`${assetsPublicPath}js/mazer.js`)
  .setPublicPath("public")
  .options({
    processCssUrls: false,
  });

// mix.njk("src/*.html", "dist/", {
//   ext: ".html",
//   watch: true,
//   data: {
//     web_title: "Mazer Admin Dashboard",
//     sidebarItems,
//     horizontalMenuItems,
//   },
//   block: "content",
//   envOptions: {
//     watch: true,
//     noCache: true,
//   },
//   manageEnv: (nunjucks) => {
//     nunjucks.addFilter("containString", (str, containStr) => {
//       if (!str.length) return false;
//       return str.indexOf(containStr) >= 0;
//     });
//     nunjucks.addFilter("startsWith", (str, targetStr) => {
//       if (!str.length) return false;
//       return str.startsWith(targetStr);
//     });
//   },
// });
