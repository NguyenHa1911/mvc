<?php

namespace App\Supports\Helpers;

trait MenuActiveUrlHelper {

    public static function getFirstPathUrl($url) {
        $url_path = parse_url($url, PHP_URL_PATH);
        if (is_null($url_path)) return '/';

        $path_array = explode('/', $url_path);
        return $path_array[1] ?? '404';
    }
}