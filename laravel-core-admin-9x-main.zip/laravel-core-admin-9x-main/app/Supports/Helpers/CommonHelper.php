<?php

namespace App\Supports\Helpers;

class CommonHelper {
    use MenuActiveUrlHelper;
}