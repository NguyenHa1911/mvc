<?php

namespace App\Providers;

use App\Console\Commands\MakeFile\MakeBaseControllerCommand;
use App\Console\Commands\MakeFile\MakeServiceCommand;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        // Command make custom file
        $this->commands(MakeBaseControllerCommand::class);
        $this->commands(MakeServiceCommand::class);
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
