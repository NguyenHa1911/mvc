<?php

namespace App\Core;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;

class RealtimeCore extends Controller
{
    /***
     * room: Socket Room
     * channel: Socket on channel
     * data: []
     */
    public static function send($room, $channel, $data)
    {
        $data = array(
            "channel" => $channel,
            "room" => $room,
            "data" =>  $data
        );
        $response =  Http::post(env("APP_REALTIME_URL") . '/callback', $data);
        return $response;
    }
}
