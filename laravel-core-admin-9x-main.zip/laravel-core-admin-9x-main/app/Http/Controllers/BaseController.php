<?php

namespace App\Http\Controllers;

use App\Traits\DataTableTrait;

class BaseController extends Controller {
    use DataTableTrait;
}
