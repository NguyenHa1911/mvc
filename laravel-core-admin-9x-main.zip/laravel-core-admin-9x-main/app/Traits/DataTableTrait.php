<?php

namespace App\Traits;

use Yajra\Datatables\Datatables;

trait DataTableTrait
{
    public function dataTableModel($model) {
        return Datatables::of($model)->make(true);
    }
}
