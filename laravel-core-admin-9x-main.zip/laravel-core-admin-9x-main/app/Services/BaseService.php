<?php

namespace App\Services;

/**
 * Class BaseService
 * @package App\Services
 */
class BaseService
{

}