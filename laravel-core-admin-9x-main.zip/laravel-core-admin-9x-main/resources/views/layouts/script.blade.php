<script src="{{ asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>

{{-- Jquery --}}
<script src="{{ asset('assets/vendors/jquery/jquery.min.js') }}"></script>

{{-- Datatable --}}
<script src="{{ asset('assets/vendors/jquery-datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/vendors/jquery-datatables/custom.jquery.dataTables.bootstrap5.min.js') }}"></script>

{{-- Icons --}}
<script src="assets/vendors/fontawesome/all.min.js"></script>

<script src="{{ asset('assets/js/mazer.js') }}"></script>

{{-- Datatable setting default --}}
<script src="{{ asset('assets/js/datatable/locale/vi.js') }}"></script>
<script>
$.extend( true, $.fn.dataTable.defaults, {
    searching: false,
    language: dataTableLocaleVi
} );
</script>
{{-- Page --}}
@yield('script')
