@php
$menu = [
    [
        'name' => 'Menu',
        'menu'       => [
            [
                'name'      => 'Dashboard',
                'url'       => route('admin.dashboard.view'),
                'url_name'  => CommonHelper::getFirstPathUrl(route('admin.dashboard.view')),
                'icon'      => '<i class="bi bi-grid-fill"></i>',
                'menu'      => []
            ],
            [
                'name'      => 'User',
                'url'       => route('admin.user.list.view'),
                'url_name'  => CommonHelper::getFirstPathUrl(route('admin.user.list.view')),
                'icon'      => '<i class="fa fa-user"></i>',
                'menu'      => []
            ],
            [
                'name'  => 'Components',
                'url'   => '/component',
                'url_name'  => CommonHelper::getFirstPathUrl('componect'),
                'icon'  => '<i class="bi bi-stack"></i>',
                'menu'  => [
                    [
                        'name'  => 'Alert',
                        'url'   => '/alert',
                    ],
                    [
                        'name'  => 'Badge',
                        'url'   => '/badge',
                    ],
                    [
                        'name'  => 'Breadcrumb',
                        'url'   => '/breadcrumb',
                    ],
                    [
                        'name'  => 'Card',
                        'url'   => '/card',
                    ],
                    [
                        'name'  => 'Carousel',
                        'url'   => '/carousel',
                    ],
                    [
                        'name'  => 'Breadcrumb',
                        'url'   => '/breadcrumb',
                    ],
                    [
                        'name'  => 'Dropdown',
                        'url'   => '/dropdown',
                    ],
                ]
            ]
        ]
    ]
];
@endphp
<ul class="menu">
    @foreach ($menu as $item)
        <li class="sidebar-title">{{ $item['name'] }}</li>
        @foreach($item['menu'] as $submenu1)
            <li
                class="sidebar-item {{ count($submenu1['menu']) > 0 ? 'has-sub' : '' }} {{ request()->is($submenu1['url_name'] .'*') ? 'active' : '' }} ">
                <a href="{{ $submenu1['url'] }}" class='sidebar-link'>
                    {!! $submenu1['icon'] !!}
                    <span>{{ $submenu1['name'] }}</span>
                </a>
                @if(count($submenu1['menu']))
                    <ul class="submenu ">
                        @foreach($submenu1['menu'] as $submenu2)
                            <li class="submenu-item ">
                                <a href="{{ $submenu2['url'] }}">{{ $submenu2['name'] }}</a>
                            </li>
                        @endforeach
                    </ul>
                @endif
            </li>
        @endforeach
    @endforeach
</ul>