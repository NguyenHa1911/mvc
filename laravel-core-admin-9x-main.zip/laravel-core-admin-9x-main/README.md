# LARAVEL CORE ADMIN TJENNT 9.0

## Theme Mazer
```
- Demo base: https://zuramai.github.io/mazer/demo/index.html
```

## Make custom file

- Make controller extends BaseController:
```
php artisan make:basecontroller {Controller name}
```

- Make service extends BaseService:
```
php artisan make:service {Service name}
```


## 

## Debug dump server
```
php artisan dump:server
```
